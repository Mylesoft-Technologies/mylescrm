# MylesCRM — AI-Powered Multi-Tenant SaaS CRM

> Built by **Jonathan Ayany** | Mylesoft Technologies
> Contact: ayany004@gmail.com | 0743993715 | 0751812884

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | Next.js 15 (App Router), TypeScript, Tailwind CSS |
| Backend | Convex (real-time DB + serverless functions) |
| Auth | WorkOS AuthKit (SSO, Google, GitHub, MFA) |
| Email | Resend (transactional + tracking) |
| Payments | Stripe + M-Pesa Daraja (STK Push) |
| AI | OpenRouter API (Claude 3.5 Sonnet, GPT-4o-mini) |
| Scheduling | Cal.com |
| Deployment | Vercel |

---

## Quick Start

### 1. Install
```bash
npm install
```

### 2. Environment
```bash
cp .env.example .env.local
# Fill in all values
```

### 3. Convex
```bash
npx convex dev
```

### 4. Run
```bash
npm run dev
```

---

## Key Commands

| Command | Action |
|---|---|
| `npm run dev` | Start Next.js + Convex dev together |
| `npx convex dev` | Run Convex backend only |
| `npx convex deploy` | Deploy Convex to production |
| `vercel` | Deploy to Vercel |

---

## DB Schema (21 Tables)
organizations, users, contacts, companies, pipelines, pipeline_stages,
deals, activities, tasks, email_messages, email_templates, email_sequences,
invoices, payments, subscriptions, ai_conversations, lead_scores,
notifications, custom_fields, reports, webhook_logs

---

## Roles
super_admin, admin, sales_manager, sales_rep, finance_officer, viewer

---

## AI Features
- Lead Scoring (A-F grade, 0-100 score)
- AI Chat Assistant (CRM-context aware)
- Email Drafting (intent-based, AI-generated)
- Revenue Forecasting (3-scenario, monthly breakdown)
